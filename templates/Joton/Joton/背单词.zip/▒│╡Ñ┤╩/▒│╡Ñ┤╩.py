import ybc_box as box
import ybc_trans as trans
import ybc_speech as sp
import ybc_player as player
import ybc_exception
from PIL import Image,ImageDraw,ImageFont
import random
import os
def word():
    op = box.buttonbox('选择想要的内容',['初始化词库','编辑词库','复习词库'])
    if op == '初始化词库':
        dict = {
                'apple':'苹果',
                'banana':'香蕉',
                'orange':'橙子'
        }
        while True:
            for w in dict:
                box.msgbox(w + '\n' + dict[w], w + '.jpg')
                voice = sp.text2voice(w,w+'.wav')
                player.play(voice)
            yn = box.ynbox('你都记住了吗？')
            if yn:
                break
        words = []
        for w in dict:
            words.append(w)
        random.shuffle(words)
        box.msgbox('第一关，英译汉')
        for w in words :
            voice = sp.text2voice(w, w + '.wav')
            player.play(voice)
            e = box.enterbox('请输入中文意思')
            if e == dict[w]:
                box.msgbox('回答正确，真棒！')
            else:
                box.msgbox('回答错误，正确写法为' + dict[w])
        box.msgbox('第二关：汉译英')
        for w in words:
            e = box.enterbox(dict[w])
            if e.lower() == w.lower():
                box.msgbox('回答正确，真棒！')
            else:
                box.msgbox('回答错误，正确写法为' + w)
    elif op == '编辑词库':
        op1 = box.buttonbox('选择编辑方法',['从单词库增加单词','自定义词库'])
        if op1 == '从单词库增加单词':
            yn = box.ynbox('是否确定添加词汇个数')
            yn1 = box.ynbox('是否添加进词库')
            f = open('单词.txt', 'r', encoding='utf-8-sig')
            text = f.read()
            f.close()
            text = text.split('\n')
            if yn:
                g = box.intbox('请输入单词个数')
                if g <= 0:
                    box.msgbox('输入数字错误')
                wordlist = []
                dict = {}
                text.remove('版权为吴洲桐所有')
                for i in range(g):
                    op2 = box.choicebox('选择想要的词汇',text)
                    if op2 == None:
                        break
                    text.remove(op2)
                    zh = trans.en2zh(op2)
                    op2 = op2.replace(' ', '')
                    wordlist.append(op2)
                    dict[op2] = zh
                    img = Image.new('RGB', (200, 100), (255, 255, 255))
                    draw = ImageDraw.Draw(img)
                    font = ImageFont.truetype('STHUPO.TTF', 48)
                    chat = zh
                    color = (random.randint(0, 255),
                             random.randint(0, 255),
                             random.randint(0, 255))
                    draw.text([50, 20], chat, color, font)
                    img.save(op2 + '.jpg')
            else:
                wordlist = []
                dict = {}
                text.remove('版权为吴洲桐所有')
                while True:
                    op2 = box.choicebox('选择想要的词汇', text)
                    if op2 == None:
                        break
                    text.remove(op2)
                    zh = trans.en2zh(op2)
                    op2 = op2.replace(' ', '')
                    wordlist.append(op2)
                    dict[op2] = zh
                    img = Image.new('RGB', (200, 100), (255, 255, 255))
                    draw = ImageDraw.Draw(img)
                    font = ImageFont.truetype('STHUPO.TTF', 48)
                    chat = zh
                    color = (random.randint(0, 255),
                             random.randint(0, 255),
                             random.randint(0, 255))
                    draw.text([50, 20], chat, color, font)
                    img.save(op2 + '.jpg')
            if yn1:
                name = box.enterbox('请输入词库名')
                if name != None:
                    if name != '单词':
                        f = open(name+'.txt','w')
                        wordlist = set(wordlist)
                        wordlist = list(wordlist)
                        f.write(str(wordlist))
                        f.close()
                    else:
                        box.msgbox('词库重名')
            if dict != {}:
                while True:
                    for w in dict:
                        w = w.replace(' ','')
                        box.msgbox(w + '\n' + dict[w], w + '.jpg')
                        voice = sp.text2voice(w, w + '.wav')
                        player.play(voice)
                    yn = box.ynbox('你都记住了吗？')
                    if yn:
                        break
                words = []
                for w in dict:
                    words.append(w)
                random.shuffle(words)
                box.msgbox('第一关，英译汉')
                for w in words:
                    voice = sp.text2voice(w, w + '.wav')
                    player.play(voice)
                    e = box.enterbox('请输入中文意思')
                    if e == dict[w]:
                        box.msgbox('回答正确，真棒！')
                    else:
                        box.msgbox('回答错误，正确写法为' + dict[w])
                box.msgbox('第二关：汉译英')
                for w in words:
                    e = box.enterbox(dict[w])
                    if e.lower() == w.lower():
                        box.msgbox('回答正确，真棒！')
                    else:
                        box.msgbox('回答错误，正确写法为' + w)
        elif op1 == '自定义词库':
            op3 = box.buttonbox('选择输入的语言',['英文','中文'])
            if op3 == '英文':
                yn = box.ynbox('是否确定添加词汇个数')
                yn1 = True
                if yn:
                    g = box.intbox('请输入单词个数')
                    if g <= 0:
                        box.msgbox('输入数字错误')
                    wordlist = []
                    dict = {}
                    for i in range(g):
                        en = box.enterbox('请输入单词(英)')
                        if en == None:
                            break
                        zh = trans.en2zh(en)
                        en = en.replace(' ', '')
                        wordlist.append(en)
                        dict[en] = zh
                        img = Image.new('RGB', (200, 100), (255, 255, 255))
                        draw = ImageDraw.Draw(img)
                        font = ImageFont.truetype('STHUPO.TTF', 48)
                        chat = zh
                        color = (random.randint(0, 255),
                                 random.randint(0, 255),
                                 random.randint(0, 255))
                        draw.text([50, 20], chat, color, font)
                        img.save(en + '.jpg')
                else:
                    wordlist = []
                    dict = {}
                    while True:
                        en = box.enterbox('请输入单词(英)')
                        if en == None:
                            break
                        zh = trans.en2zh(en)
                        en = en.replace(' ', '')
                        wordlist.append(en)
                        dict[en] = zh
                        img = Image.new('RGB', (200, 100), (255, 255, 255))
                        draw = ImageDraw.Draw(img)
                        font = ImageFont.truetype('STHUPO.TTF', 48)
                        chat = zh
                        color = (random.randint(0, 255),
                                 random.randint(0, 255),
                                 random.randint(0, 255))
                        draw.text([50, 20], chat, color, font)
                        img.save(en + '.jpg')
                if yn1:
                    name = box.enterbox('请输入词库名不要包括‘(错题本)’')
                    if name != None:
                        if name != '单词' and '(错题本)' not in name:
                            lists = os.listdir()
                            if name + '.txt' not in lists:
                                f = open(name + '.txt', 'w')
                                wordlist = set(wordlist)
                                wordlist = list(wordlist)
                                f.write(str(wordlist))
                                f.close()
                            else:
                                box.msgbox('词库重名')
                        else:
                            box.msgbox('词库重名')
                if dict != {}:
                    while True:
                        for w in dict:
                            w = w.replace(' ', '')
                            box.msgbox(w + '\n' + dict[w], w + '.jpg')
                            voice = sp.text2voice(w, w + '.wav')
                            player.play(voice)
                        yn = box.ynbox('你都记住了吗？')
                        if yn:
                            break
                    words = []
                    for w in dict:
                        words.append(w)
                    random.shuffle(words)
                    box.msgbox('第一关，英译汉')
                    for w in words:
                        voice = sp.text2voice(w, w + '.wav')
                        player.play(voice)
                        e = box.enterbox('请输入中文意思')
                        if e == dict[w]:
                            box.msgbox('回答正确，真棒！')
                        else:
                            box.msgbox('回答错误，正确写法为' + dict[w])
                    box.msgbox('第二关：汉译英')
                    for w in words:
                        e = box.enterbox(dict[w])
                        if e.lower() == w.lower():
                            box.msgbox('回答正确，真棒！')
                        else:
                            box.msgbox('回答错误，正确写法为' + w)
            elif op3 == '中文':
                yn = box.ynbox('是否确定添加词汇个数')
                yn1 = True
                if yn:
                    g = box.intbox('请输入单词个数')
                    if g <= 0:
                        box.msgbox('输入数字错误')
                    wordlist = []
                    dict = {}
                    for i in range(g):
                        zh = box.enterbox('请输入单词(中)')
                        if zh == None:
                            break
                        en = trans.zh2en(zh)
                        en = en.replace(' ', '')
                        wordlist.append(en)
                        dict[en] = zh
                        img = Image.new('RGB', (200, 100), (255, 255, 255))
                        draw = ImageDraw.Draw(img)
                        font = ImageFont.truetype('STHUPO.TTF', 48)
                        chat = zh
                        color = (random.randint(0, 255),
                                 random.randint(0, 255),
                                 random.randint(0, 255))
                        draw.text([50, 20], chat, color, font)
                        img.save(en + '.jpg')
                else:
                    wordlist = []
                    dict = {}
                    while True:
                        zh = box.enterbox('请输入单词(中)')
                        if zh == None:
                            break
                        en = trans.zh2en(zh)
                        en = en.replace(' ','')
                        wordlist.append(en)
                        dict[en] = zh
                        img = Image.new('RGB', (200, 100), (255, 255, 255))
                        draw = ImageDraw.Draw(img)
                        font = ImageFont.truetype('STHUPO.TTF', 48)
                        chat = zh
                        color = (random.randint(0, 255),
                                 random.randint(0, 255),
                                 random.randint(0, 255))
                        draw.text([50, 20], chat, color, font)
                        img.save(en + '.jpg')
                if yn1:
                    name = box.enterbox('请输入词库名')
                    if name != None:
                        if name != '单词' and '(错题本)' not in name:
                            f = open(name + '.txt', 'w')
                            f.write(str(wordlist))
                            f.close()
                        else:
                            box.msgbox('词库重名')
                if dict != {}:
                    while True:
                        for w in dict:
                            w = w.replace(' ', '')
                            print(w)
                            box.msgbox(w + '\n' + dict[w], w + '.jpg')
                            voice = sp.text2voice(w, w + '.wav')
                            player.play(voice)
                        yn = box.ynbox('你都记住了吗？')
                        if yn:
                            break
                    words = []
                    for w in dict:
                        words.append(w)
                    random.shuffle(words)
                    box.msgbox('第一关，英译汉')
                    for w in words:
                        voice = sp.text2voice(w, w + '.wav')
                        player.play(voice)
                        e = box.enterbox('请输入中文意思')
                        if e == dict[w]:
                            box.msgbox('回答正确，真棒！')
                        else:
                            box.msgbox('回答错误，正确写法为' + dict[w])
                    box.msgbox('第二关：汉译英')
                    for w in words:
                        e = box.enterbox(dict[w])
                        if e.lower() == w.lower():
                            box.msgbox('回答正确，真棒！')
                        else:
                            box.msgbox('回答错误，正确写法为' + w)
    elif op == '复习词库':
        fuxi = box.fileopenbox('选择复习的词库(请勿选单词.txt)')
        if '(错题本)' in fuxi:
            box.msgbox('全部答对后错题本将删除')
            f = open(fuxi, 'r', encoding='utf-8-sig')
            fuxilist = f.read()
            f.close()
            fuxilist = eval(fuxilist)
            fuxilist = set(fuxilist)
            fuxilist = list(fuxilist)
            dict = {}
            flag = True
            fblujing = os.path.abspath(fuxi)
            os.remove(fblujing)
            fbyn = box.ynbox('是否将错题覆盖进错题本')
            if fbyn:
                fblist = []
                fblujing = os.path.abspath(fuxi)
                os.remove(fblujing)
            for en in fuxilist:
                zh = trans.en2zh(en)
                dict[en] = zh
                img = Image.new('RGB', (200, 100), (255, 255, 255))
                draw = ImageDraw.Draw(img)
                font = ImageFont.truetype('STHUPO.TTF', 48)
                chat = zh
                color = (random.randint(0, 255),
                         random.randint(0, 255),
                         random.randint(0, 255))
                draw.text([50, 20], chat, color, font)
                img.save(en + '.jpg')
            while True:
                for w in dict:
                    w = w.replace(' ', '')
                    box.msgbox(w + '\n' + dict[w], w + '.jpg')
                    voice = sp.text2voice(w, w + '.wav')
                    player.play(voice)
                yn = box.ynbox('你都记住了吗？')
                if yn:
                    break
            words = []
            for w in dict:
                words.append(w)
            random.shuffle(words)
            box.msgbox('第一关，英译汉')
            for w in words:
                voice = sp.text2voice(w, w + '.wav')
                player.play(voice)
                e = box.enterbox('请输入中文意思')
                if e == dict[w]:
                    box.msgbox('回答正确，真棒！')
                else:
                    box.msgbox('回答错误，正确写法为' + dict[w])
                    flag = False
                    if fbyn:
                        fblist.append(w)
            box.msgbox('第二关：汉译英')
            for w in words:
                e = box.enterbox(dict[w])
                if e.lower() == w.lower():
                    box.msgbox('回答正确，真棒！')
                else:
                    box.msgbox('回答错误，正确写法为' + w)
                    flag = False
                    if fbyn:
                        fblist.append(w)
            if fbyn:
                fuxi = fuxi.replace('.txt', '')
                f = open(fuxi + '(错题本).txt', 'w')
                fblist = set(fblist)
                fblist = list(fblist)
                f.write(str(fblist))
                f.close()
            if flag:
                fblujing = os.path.abspath(fuxi)
                os.remove(fblujing)
        elif fuxi != None:
            f = open(fuxi,'r',encoding='utf-8-sig')
            fuxilist = f.read()
            f.close()
            if '版权为吴洲桐所有' in fuxilist:
                box.msgbox('请勿选择单词.txt')
            elif '�' in fuxilist:
                box.msgbox('复习词库出现乱码')
            else:
                fbyn = box.ynbox('是否将错题添加进错题本')
                if fbyn:
                    fblist = []
                fuxilist = eval(fuxilist)
                fuxilist = set(fuxilist)
                fuxilist = list(fuxilist)
                dict = {}
                for en in fuxilist:
                    zh = trans.en2zh(en)
                    dict[en] = zh
                    img = Image.new('RGB', (200, 100), (255, 255, 255))
                    draw = ImageDraw.Draw(img)
                    font = ImageFont.truetype('STHUPO.TTF', 48)
                    chat = zh
                    color = (random.randint(0, 255),
                             random.randint(0, 255),
                             random.randint(0, 255))
                    draw.text([50, 20], chat, color, font)
                    img.save(en + '.jpg')
                while True:
                    for w in dict:
                        w = w.replace(' ', '')
                        box.msgbox(w + '\n' + dict[w], w + '.jpg')
                        voice = sp.text2voice(w, w + '.wav')
                        player.play(voice)
                    yn = box.ynbox('你都记住了吗？')
                    if yn:
                        break
                words = []
                for w in dict:
                    words.append(w)
                random.shuffle(words)
                box.msgbox('第一关，英译汉')
                for w in words:
                    voice = sp.text2voice(w, w + '.wav')
                    player.play(voice)
                    e = box.enterbox('请输入中文意思')
                    if e == dict[w]:
                        box.msgbox('回答正确，真棒！')
                    else:
                        box.msgbox('回答错误，正确写法为' + dict[w])
                        if fbyn:
                            fblist.append(w)
                box.msgbox('第二关：汉译英')
                for w in words:
                    e = box.enterbox(dict[w])
                    if e.lower() == w.lower():
                        box.msgbox('回答正确，真棒！')
                    else:
                        box.msgbox('回答错误，正确写法为' + w)
                        if fbyn:
                            fblist.append(w)
                if fbyn:
                    fuxi = fuxi.replace('.txt','')
                    f = open(fuxi + '(错题本).txt', 'w')
                    fblist = set(fblist)
                    fblist = list(fblist)
                    f.write(str(fblist))
                    f.close()

if __name__ == '__main__':
    try:
        word()
    except ybc_exception.exception.InternalError:
        box.msgbox('获取音频失败，无法播放。推荐mp3音频默认使用Groove音乐播放，可到Microsoft Store下载')
    except UnicodeDecodeError:
        box.msgbox('请选择正确的文件，若操作无误，可上报作者。QQ:3149920698')
    except SyntaxError:
        box.msgbox('语法错误，若操作无误，可上报作者。QQ:3149920698')
    except TypeError:
        box.msgbox('文件类型错误，若操作无误，可上报作者。QQ:3149920698')
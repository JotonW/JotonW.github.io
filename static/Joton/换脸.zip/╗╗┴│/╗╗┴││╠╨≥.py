import tkinter as tk  # 导入tk
import tkinter.filedialog
from PIL import Image,ImageTk
import json
import simplejson
import base64
import requests

string01 = ''
string02 = ''
string03 = ''

def getEntry01():
    global string01
    global e1
    selectFileName1 = tk.filedialog.askopenfilename(title='选择文件')
    e1.set(selectFileName1)
    load = Image.open(selectFileName1)
    load = load.resize((150, 150))
    render = ImageTk.PhotoImage(load)
    img = tkinter.Label(image=render)
    img.image = render
    img.place(x=115, y=45)
    string01 = selectFileName1
    #print(string01)

def getEntry02():
    global string02
    global e2
    selectFileName2 = tk.filedialog.askopenfilename(title='选择文件')
    e2.set(selectFileName2)
    load = Image.open(selectFileName2)
    load = load.resize((150, 150))
    render = ImageTk.PhotoImage(load)
    img = tkinter.Label(image=render)
    img.image = render
    img.place(x=115, y=245)
    string02 = selectFileName2
    #print(string02)


#第一步：获取人脸关键点
def find_face(imgpath):
    """
    :param imgpath: 图片的地址
    :return: 一个字典类型的人脸关键点 如：{'top': 156, 'left': 108, 'width': 184, 'height': 184}
    """
    http_url = 'https://api-cn.faceplusplus.com/facepp/v3/detect' #获取人脸信息的接口
    data = {
        "api_key":"x2NyKaa6vYuArYwat4x0-NpIbM9CrwGU",#访问url所需要的参数
        "api_secret":"OuHx-Xaey1QrORwdG7QetGG5JhOIC8g7",#访问url所需要的参数
        "image_url":imgpath, #图片地址
        "return_landmark":1
    }


    files = {'image_file':open(imgpath,'rb')} #定义一个字典存放图片的地址
    response = requests.post(http_url,data=data,files=files)
    res_con1 = response.content.decode('utf-8')
    res_json = simplejson.loads(res_con1)
    faces = res_json['faces']
    list = faces[0]
    rectangle = list['face_rectangle']
    return rectangle

#第二步：实现换脸
def merge_face(image_url1,image_url2,image_url,number):
    """
    :param image_url1: 被换脸的图片路径
    :param image_url2: 换脸的图片路径
    :param image_url: 换脸后生成图片所保存的路径
    :param number: 换脸的相似度
    """
    #首先获取两张图片的人脸关键点
    face1 = find_face(image_url1)
    face2 = find_face(image_url2)
    #将人脸转换为字符串的格式
    rectangle1 = str(str(face1['top']) + "," + str(face1['left']) + "," + str(face1['width']) + "," + str(face1['height']))
    rectangle2 = str(str(face2['top']) + "," + str(face2['left']) + "," + str(face2['width']) + "," + str(face2['height']))
    #读取两张图片
    f1 = open(image_url1,'rb')
    f1_64 = base64.b64encode(f1.read())
    f1.close()
    f2 = open(image_url2, 'rb')
    f2_64 = base64.b64encode(f2.read())
    f2.close()

    url_add = 'https://api-cn.faceplusplus.com/imagepp/v1/mergeface' #实现换脸的接口
    data={
        "api_key": "x2NyKaa6vYuArYwat4x0-NpIbM9CrwGU",
        "api_secret": "OuHx-Xaey1QrORwdG7QetGG5JhOIC8g7",
        "template_base64":f1_64,
        "template_rectangle":rectangle1,
        "merge_base64":f2_64,
        "merge_rectangle":rectangle2,
        "merge_rate":number
    }
    response1 = requests.post(url_add,data=data)
    res_con1 = response1.content.decode('utf-8')
    print(response1)
    res_dict = json.JSONDecoder().decode(res_con1)
    print(response1)
    result = res_dict['result']
    imgdata = base64.b64decode(result)
    file=open(image_url,'wb')
    file.write(imgdata)
    file.close()

def getEntry03():
    global string03
    global string01
    global string02
    #string03 = "./face/0003.jpg"
    string03 = "./0003.jpg"
    print(string03)
    merge_face(string01, string02, string03, 100)
    load = Image.open(string03)
    load = load.resize((250, 250))
    render = ImageTk.PhotoImage(load)
    img = tkinter.Label(image=render)
    img.image = render
    img.place(x=72, y=445)

def clear():
    entry.delete(0,'end') # 删除清空Entry控件的内容

font = ('微软雅黑', 12)
root = tk.Tk()
root.title('换脸游戏')
root.geometry('400x800') # 设定窗口的大小

e1 = tk.StringVar()  # 文本输入框
e1_entry = tk.Entry(root, width=68, textvariable=e1)
e2 = tk.StringVar()  # 文本输入框
e2_entry = tk.Entry(root, width=68, textvariable=e2)

button01 = tk.Button(root,text='获取img1',font=font,command=getEntry01,padx=50,pady=3)
button01.pack()
button01.place(x=112, y=0)

button02 = tk.Button(root,text='获取img2',font=font,command=getEntry02,padx=50,pady=3)
button02.pack()
button02.place(x=112, y=200)

button03 = tk.Button(root,text='点击换脸',font=font,command=getEntry03,padx=50,pady=3)
button03.pack()
button03.place(x=112, y=400)


button04 = tk.Button(root,text='退出程序',font=font, command=root.quit,padx=50,pady=3)
button04.pack()
button04.place(x=100, y=600)





root.mainloop()
